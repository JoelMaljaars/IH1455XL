import 'package:flutter/material.dart';

const lichtgrijs = Color(0xFFECECEC);
const zwart = Color(0xFF000000);

const blauw = Color(0xFF3182A0);